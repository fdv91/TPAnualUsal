package edu.usal.negocio.dto;

import java.util.*;

public class Ventas {
	
	Date fechaVenta, horaVenta;
	String formaPago;
	
	void Cliente(){
		
	}
	
	void Vuelo() {
		
	}
	
	void Aerolinea() {
		
	}
}
