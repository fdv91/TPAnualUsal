package edu.usal.negocio.dto;

public class DireccionCompleta {

}
